export type Role = "Bartender" | "Manager";
export type Language = "en" | "km";

export interface User {
  id: string;
  name: string;
  pin: string;
  role: Role;
  active: boolean;
}

export interface Supplier {
  id: string;
  name: string;
  contact: string;
  category: string;
  address?: string;
  email?: string;
}

export interface WasteLog {
  id: string;
  stockItemId: string;
  quantity: number;
  reason: string;
  timestamp: number;
  processedBy: string;
}

export interface StockIn {
  id: string;
  supplierId: string;
  items: {
    stockItemId: string;
    quantity: number;
    costPrice: number;
  }[];
  totalCost: number;
  invoicePhoto?: string;
  timestamp: number;
  staffMember: string;
}

export interface LoyaltyMember {
  id: string;
  name: string;
  phone: string;
  points: number;
  visitCount: number;
  lastVisit: number;
}

export interface StockItem {
  id: string;
  name: string;
  nameKh?: string;
  category: "Spirit" | "Mixer" | "Garnish" | "Beer" | "Soft Drink";
  unit: "bottle" | "ml" | "can" | "piece";
  quantity: number;
  minThreshold: number;
  costPerUnit: number;
  supplierId?: string;
}

export interface Cocktail {
  id: string;
  name: string;
  nameKh?: string;
  price: number;
  ingredients: {
    stockItemId: string;
    amount: number;
  }[];
}

export interface Expense {
  id: string;
  timestamp: number;
  description: string;
  amount: number;
  category: string;
  staffMember: string;
  type: 'Expense' | 'CashTaken' | 'CashReturned';
}

export interface SaleItem {
  id: string;
  name: string;
  nameKh?: string;
  price: number;
  quantity: number;
  type: "cocktail" | "stockItem";
}

export interface Order {
  id: string;
  timestamp: number;
  items: SaleItem[];
  total: number;
  paymentMethod: "Cash" | "ABA" | "Tab";
  status: "Completed" | "Pending" | "OpenTab";
  processedBy: string;
  customerName?: string;
}

export interface Tab {
  id: string;
  customerName: string;
  items: SaleItem[];
  total: number;
  status: "Open" | "Closed";
  openedAt: number;
  closedAt?: number;
}
