import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import ReactMarkdown from 'react-markdown';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  LineChart, 
  Line,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import { StockItem, Cocktail, Order, SaleItem, User, Role, Language, Expense, Tab, Supplier, WasteLog, StockIn, LoyaltyMember } from './types';
import { getPricingSuggestions, generateWeeklyReport } from './services/geminiService';
import { printReceipt } from './services/printerService';
import { translations } from './translations';
import { syncToGoogleSheets, getOfflineData } from './services/syncService';
import { 
  LayoutDashboard, 
  ShoppingCart, 
  Package, 
  Wine, 
  TrendingUp, 
  Settings, 
  Plus, 
  Minus, 
  Trash2, 
  QrCode, 
  DollarSign,
  AlertCircle,
  Sparkles,
  ChevronRight,
  LogOut,
  FileText,
  Printer,
  User as UserIcon,
  Lock,
  Grid3X3,
  Users,
  Wallet,
  Clock,
  Globe,
  CloudOff,
  Cloud
} from 'lucide-react';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// --- Mock Data ---
const USERS: User[] = [
  { id: 'u1', name: 'Sophea', pin: '1234', role: 'Manager', active: true },
  { id: 'u2', name: 'Dara', pin: '0000', role: 'Bartender', active: true },
];

const INITIAL_SUPPLIERS: Supplier[] = [
  { id: 's1', name: 'Attwood Import Export', contact: '012 345 678', category: 'Spirits', address: 'Phnom Penh', email: 'sales@attwood.com' },
  { id: 's2', name: 'Local Market', contact: 'N/A', category: 'Garnish' },
];

const INITIAL_STOCK: StockItem[] = [
  { id: '1', name: 'Gin (Tanqueray)', nameKh: 'ហ្ស៊ីន (Tanqueray)', category: 'Spirit', unit: 'ml', quantity: 700, minThreshold: 200, costPerUnit: 0.03, supplierId: 's1' },
  { id: '2', name: 'Tonic Water', nameKh: 'ទឹកតូនិក', category: 'Mixer', unit: 'ml', quantity: 1000, minThreshold: 300, costPerUnit: 0.002, supplierId: 's1' },
  { id: '3', name: 'Lime', nameKh: 'ក្រូចឆ្មារ', category: 'Garnish', unit: 'piece', quantity: 20, minThreshold: 5, costPerUnit: 0.1, supplierId: 's2' },
  { id: '4', name: 'Angkor Beer', nameKh: 'ស្រាបៀរអង្គរ', category: 'Beer', unit: 'can', quantity: 48, minThreshold: 12, costPerUnit: 0.6, supplierId: 's1' },
];

const INITIAL_COCKTAILS: Cocktail[] = [
  { 
    id: 'c1', 
    name: 'Gin & Tonic', 
    nameKh: 'ហ្ស៊ីនតូនិក',
    price: 5.5, 
    ingredients: [
      { stockItemId: '1', amount: 50 },
      { stockItemId: '2', amount: 150 },
      { stockItemId: '3', amount: 0.5 },
    ] 
  }
];

export default function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [pinInput, setPinInput] = useState('');
  const [lang, setLang] = useState<Language>('en');
  const [activeTab, setActiveTab] = useState<'pos' | 'inventory' | 'cocktails' | 'reports' | 'expenses' | 'tabs' | 'staff' | 'suppliers' | 'history' | 'loyalty' | 'analytics' | 'waste' | 'stockIn'>('pos');
  const [users, setUsers] = useState<User[]>(USERS);
  const [stock, setStock] = useState<StockItem[]>(INITIAL_STOCK);
  const [cocktails, setCocktails] = useState<Cocktail[]>(INITIAL_COCKTAILS);
  const [suppliers, setSuppliers] = useState<Supplier[]>(INITIAL_SUPPLIERS);
  const [cart, setCart] = useState<SaleItem[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [tabs, setTabs] = useState<Tab[]>([]);
  const [wasteLogs, setWasteLogs] = useState<WasteLog[]>([]);
  const [stockInLogs, setStockInLogs] = useState<StockIn[]>([]);
  const [loyaltyMembers, setLoyaltyMembers] = useState<LoyaltyMember[]>([]);
  const [customerName, setCustomerName] = useState('');
  const [isAbaModalOpen, setIsAbaModalOpen] = useState(false);
  const [abaQr, setAbaQr] = useState<string | null>(null);
  const [aiLoading, setAiLoading] = useState(false);
  const [aiReport, setAiReport] = useState<string | null>(null);
  const [pricingSuggestions, setPricingSuggestions] = useState<string | null>(null);
  const [isPrinting, setIsPrinting] = useState(false);
  const [isHappyHour, setIsHappyHour] = useState(false);
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [googleTokens, setGoogleTokens] = useState<any>(null);

  const t = translations[lang];

  // --- Effects ---
  useEffect(() => {
    const handleMessage = (event: MessageEvent) => {
      if (event.data?.type === 'GOOGLE_AUTH_SUCCESS') {
        setGoogleTokens(event.data.tokens);
        localStorage.setItem('google_tokens', JSON.stringify(event.data.tokens));
      }
    };
    window.addEventListener('message', handleMessage);
    
    const savedTokens = localStorage.getItem('google_tokens');
    if (savedTokens) {
      try {
        setGoogleTokens(JSON.parse(savedTokens));
      } catch (e) {
        console.error("Failed to parse saved tokens", e);
      }
    }

    return () => window.removeEventListener('message', handleMessage);
  }, []);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    
    // Auto-sync every 5 minutes if online
    const interval = setInterval(() => {
      if (isOnline && googleTokens) {
        syncToGoogleSheets({ orders, stock, expenses }, googleTokens);
      }
    }, 300000);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      clearInterval(interval);
    };
  }, [isOnline, googleTokens, orders, stock, expenses]);

  // Happy Hour Notification
  useEffect(() => {
    const checkHappyHour = () => {
      const now = new Date();
      const hour = now.getHours();
      // Default Happy Hour: 5 PM to 7 PM
      if (hour >= 17 && hour < 19) {
        if (!isHappyHour) {
          setIsHappyHour(true);
        }
      }
    };
    const interval = setInterval(checkHappyHour, 60000);
    checkHappyHour();
    return () => clearInterval(interval);
  }, [isHappyHour]);

  // --- Auth Logic ---
  const handleLogin = (pin: string) => {
    const user = users.find(u => u.pin === pin && u.active);
    if (user) {
      setCurrentUser(user);
      setPinInput('');
      setActiveTab('pos');
    } else {
      setPinInput('');
      alert('Invalid PIN');
    }
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setCart([]);
  };

  const handleConnectGoogle = async () => {
    try {
      const res = await fetch('/api/auth/google/url');
      const { url } = await res.json();
      window.open(url, 'google_auth', 'width=600,height=700');
    } catch (error) {
      console.error("Failed to get Google Auth URL", error);
    }
  };

  // --- POS Logic ---
  const addToCart = (item: Cocktail | StockItem, type: 'cocktail' | 'stockItem') => {
    setCart(prev => {
      const existing = prev.find(i => i.id === item.id);
      if (existing) {
        return prev.map(i => i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i);
      }
      
      let price = 'price' in item ? item.price : (item as StockItem).costPerUnit * 3;
      
      // Happy Hour Discount (20% off cocktails)
      if (isHappyHour && type === 'cocktail') {
        price = price * 0.8;
      }

      return [...prev, { 
        id: item.id, 
        name: lang === 'km' && item.nameKh ? item.nameKh : item.name, 
        price,
        quantity: 1,
        type 
      }];
    });
  };

  const updateCartQuantity = (id: string, delta: number) => {
    setCart(prev => prev.map(i => {
      if (i.id === id) {
        const newQty = Math.max(1, i.quantity + delta);
        return { ...i, quantity: newQty };
      }
      return i;
    }));
  };

  const cartTotal = useMemo(() => cart.reduce((sum, item) => sum + (item.price * item.quantity), 0), [cart]);

  const handleCheckout = async (method: 'Cash' | 'ABA' | 'Tab') => {
    if (method === 'ABA') {
      setIsAbaModalOpen(true);
      const res = await fetch('/api/payments/aba/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ amount: cartTotal, orderId: Date.now() })
      });
      const data = await res.json();
      setAbaQr(data.qrCode);
    } else if (method === 'Tab') {
      completeOrder('Tab');
    } else {
      completeOrder('Cash');
    }
  };

  const completeOrder = async (method: 'Cash' | 'ABA' | 'Tab') => {
    const newOrder: Order = {
      id: `ORD-${Date.now()}`,
      timestamp: Date.now(),
      items: [...cart],
      total: cartTotal,
      paymentMethod: method,
      status: method === 'Tab' ? 'OpenTab' : 'Completed',
      processedBy: currentUser?.name || 'Unknown',
      customerName: customerName || undefined
    };
    
    if (method === 'Tab') {
      const newTab: Tab = {
        id: `TAB-${Date.now()}`,
        customerName: customerName || 'Guest',
        items: [...cart],
        total: cartTotal,
        status: 'Open',
        openedAt: Date.now()
      };
      setTabs([newTab, ...tabs]);
    } else {
      // Auto-print receipt for completed orders
      setIsPrinting(true);
      await printReceipt(newOrder, "Distortion POS");
      setIsPrinting(false);
      setOrders([newOrder, ...orders]);
    }
    
    // Update Stock
    const newStock = [...stock];
    cart.forEach(item => {
      if (item.type === 'cocktail') {
        const cocktail = cocktails.find(c => c.id === item.id);
        cocktail?.ingredients.forEach(ing => {
          const stockItem = newStock.find(s => s.id === ing.stockItemId);
          if (stockItem) stockItem.quantity -= ing.amount * item.quantity;
        });
      } else {
        const stockItem = newStock.find(s => s.id === item.id);
        if (stockItem) stockItem.quantity -= item.quantity;
      }
    });

    setStock(newStock);
    setCart([]);
    setCustomerName('');
    setIsAbaModalOpen(false);
    setAbaQr(null);

    // Sync if online
    if (isOnline && googleTokens) {
      syncToGoogleSheets({ orders: [newOrder, ...orders], stock: newStock, expenses }, googleTokens);
    }
  };

  const handleAddExpense = (description: string, amount: number, category: string, type: 'Expense' | 'CashTaken' | 'CashReturned' = 'Expense') => {
    const newExpense: Expense = {
      id: `EXP-${Date.now()}`,
      description,
      amount,
      category,
      timestamp: Date.now(),
      staffMember: currentUser?.name || 'Unknown',
      type
    };
    setExpenses([newExpense, ...expenses]);
    
    if (isOnline && googleTokens) {
      syncToGoogleSheets({ orders, stock, expenses: [newExpense, ...expenses] }, googleTokens);
    }
  };

  const handleAddWaste = (stockItemId: string, quantity: number, reason: string) => {
    const item = stock.find(s => s.id === stockItemId);
    if (!item) return;

    const newLog: WasteLog = {
      id: `WST-${Date.now()}`,
      stockItemId,
      quantity,
      reason,
      timestamp: Date.now(),
      processedBy: currentUser?.name || 'Unknown'
    };

    const newStock = stock.map(s => s.id === stockItemId ? { ...s, quantity: s.quantity - quantity } : s);
    setStock(newStock);
    setWasteLogs([newLog, ...wasteLogs]);
  };

  const handleStockIn = (supplierId: string, items: { stockItemId: string, quantity: number, costPrice: number }[], totalCost: number, photo?: string) => {
    const newLog: StockIn = {
      id: `STK-${Date.now()}`,
      supplierId,
      items,
      totalCost,
      invoicePhoto: photo,
      timestamp: Date.now(),
      staffMember: currentUser?.name || 'Unknown'
    };

    const newStock = [...stock];
    items.forEach(item => {
      const s = newStock.find(si => si.id === item.stockItemId);
      if (s) {
        s.quantity += item.quantity;
        s.costPerUnit = item.costPrice; // Update cost price
      }
    });

    setStock(newStock);
    setStockInLogs([newLog, ...stockInLogs]);
  };

  const handleLoyaltyVisit = (memberId: string, pointsEarned: number) => {
    setLoyaltyMembers(loyaltyMembers.map(m => 
      m.id === memberId 
        ? { ...m, points: m.points + pointsEarned, visitCount: m.visitCount + 1, lastVisit: Date.now() }
        : m
    ));
  };

  // --- AI Logic ---
  const handleGenerateReport = async () => {
    setAiLoading(true);
    try {
      const report = await generateWeeklyReport(orders);
      setAiReport(report || "No data available.");
    } catch (e) {
      console.error(e);
    } finally {
      setAiLoading(false);
    }
  };

  const handleGetPricingSuggestions = async () => {
    setAiLoading(true);
    try {
      const suggestions = await getPricingSuggestions(cocktails, stock);
      setPricingSuggestions(suggestions || "No suggestions available.");
    } catch (e) {
      console.error(e);
    } finally {
      setAiLoading(false);
    }
  };

  // --- Login Screen ---
  if (!currentUser) {
    return (
      <div className="h-screen bg-[#0A0A0A] flex items-center justify-center p-4">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="w-full max-w-sm bg-[#141414] rounded-[2.5rem] border border-white/10 p-8 shadow-2xl"
        >
          <div className="text-center mb-10">
            <div className="w-16 h-16 bg-emerald-500 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg shadow-emerald-500/20">
              <Wine className="text-white" size={32} />
            </div>
            <h1 className="text-2xl font-bold mb-2">Distortion POS</h1>
            <p className="text-zinc-500">Enter your 4-digit PIN to start</p>
            
            <div className="flex gap-4 mt-6">
              <button 
                onClick={() => setLang('en')}
                className={cn(
                  "flex-1 py-2 rounded-xl font-bold transition-all text-sm",
                  lang === 'en' ? "bg-emerald-500 text-white" : "bg-white/5 text-zinc-500"
                )}
              >
                English
              </button>
              <button 
                onClick={() => setLang('km')}
                className={cn(
                  "flex-1 py-2 rounded-xl font-bold transition-all text-sm",
                  lang === 'km' ? "bg-emerald-500 text-white" : "bg-white/5 text-zinc-500"
                )}
              >
                ភាសាខ្មែរ
              </button>
            </div>
          </div>

          <div className="space-y-6">
            <div className="flex justify-center gap-4">
              {[0, 1, 2, 3].map(i => (
                <div 
                  key={i} 
                  className={cn(
                    "w-4 h-4 rounded-full border-2 transition-all duration-200",
                    pinInput.length > i ? "bg-emerald-500 border-emerald-500 scale-125" : "border-white/10"
                  )}
                />
              ))}
            </div>

            <div className="grid grid-cols-3 gap-4">
              {[1, 2, 3, 4, 5, 6, 7, 8, 9, 'C', 0, 'OK'].map(val => (
                <button
                  key={val}
                  onClick={() => {
                    if (val === 'C') setPinInput('');
                    else if (val === 'OK') handleLogin(pinInput);
                    else if (pinInput.length < 4) setPinInput(prev => prev + val);
                  }}
                  className={cn(
                    "h-16 rounded-2xl flex items-center justify-center text-xl font-bold transition-all active:scale-95",
                    val === 'OK' ? "bg-emerald-500 text-white" : "bg-white/5 hover:bg-white/10"
                  )}
                >
                  {val}
                </button>
              ))}
            </div>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-[#0A0A0A] text-white font-sans overflow-hidden">
      {/* Sidebar */}
      <nav className="w-20 md:w-64 bg-[#141414] border-r border-white/5 flex flex-col p-4">
        <div className="flex items-center gap-3 mb-10 px-2">
          <div className="w-10 h-10 bg-emerald-500 rounded-xl flex items-center justify-center shadow-lg shadow-emerald-500/20">
            <Wine className="text-white" size={24} />
          </div>
          <span className="hidden md:block font-bold text-xl tracking-tight">Distortion POS</span>
        </div>

        <div className="flex-1 space-y-2 overflow-y-auto pr-1">
          {[
            { id: 'pos', icon: ShoppingCart, label: t.posTerminal, roles: ['Bartender', 'Manager'] },
            { id: 'tabs', icon: Users, label: t.activeTabs, roles: ['Bartender', 'Manager'] },
            { id: 'history', icon: Clock, label: t.history, roles: ['Bartender', 'Manager'] },
            { id: 'loyalty', icon: Sparkles, label: t.loyalty, roles: ['Bartender', 'Manager'] },
            { id: 'inventory', icon: Package, label: t.inventory, roles: ['Manager'] },
            { id: 'cocktails', icon: Wine, label: t.cocktails, roles: ['Manager'] },
            { id: 'expenses', icon: Wallet, label: t.expenses, roles: ['Bartender', 'Manager'] },
            { id: 'suppliers', icon: Grid3X3, label: t.suppliers, roles: ['Manager'] },
            { id: 'staff', icon: Users, label: t.staff, roles: ['Manager'] },
            { id: 'waste', icon: Trash2, label: t.waste, roles: ['Manager'] },
            { id: 'stockIn', icon: Package, label: t.stockIn, roles: ['Manager'] },
            { id: 'reports', icon: TrendingUp, label: t.aiInsights, roles: ['Manager'] },
            { id: 'analytics', icon: LayoutDashboard, label: t.analytics, roles: ['Manager'] },
          ].filter(item => item.roles.includes(currentUser.role)).map(item => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id as any)}
              className={cn(
                "w-full flex items-center gap-4 p-3 rounded-xl transition-all duration-200 group",
                activeTab === item.id 
                  ? "bg-emerald-500 text-white shadow-lg shadow-emerald-500/20" 
                  : "text-zinc-400 hover:bg-white/5 hover:text-white"
              )}
            >
              <item.icon size={22} className={cn(activeTab === item.id ? "text-white" : "group-hover:scale-110 transition-transform")} />
              <span className="hidden md:block font-medium">{item.label}</span>
            </button>
          ))}
        </div>

        <div className="mt-auto pt-4 border-t border-white/5 space-y-4">
          <button 
            onClick={handleConnectGoogle}
            className={cn(
              "w-full flex items-center gap-4 p-3 rounded-xl transition-all",
              googleTokens 
                ? "text-emerald-500 bg-emerald-500/10" 
                : "text-zinc-500 hover:bg-white/5 hover:text-white"
            )}
          >
            {googleTokens ? <Cloud size={22} /> : <CloudOff size={22} />}
            <span className="hidden md:block font-medium">
              {googleTokens ? "Google Linked" : "Link Google"}
            </span>
          </button>

          <div className="px-3 py-2 bg-white/5 rounded-xl flex items-center gap-3">
            <div className="w-8 h-8 bg-zinc-700 rounded-full flex items-center justify-center text-xs font-bold">
              {currentUser.name[0]}
            </div>
            <div className="hidden md:block overflow-hidden">
              <p className="text-xs font-bold truncate">{currentUser.name}</p>
              <p className="text-[10px] text-zinc-500">{currentUser.role}</p>
            </div>
          </div>
          <button onClick={handleLogout} className="w-full flex items-center gap-4 p-3 rounded-xl text-zinc-500 hover:text-red-400 transition-colors">
            <LogOut size={22} />
            <span className="hidden md:block font-medium">Logout</span>
          </button>
        </div>
      </nav>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto p-4 md:p-8">
        <AnimatePresence mode="wait">
          {activeTab === 'pos' && (
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="grid grid-cols-1 lg:grid-cols-3 gap-8 h-full"
            >
              {/* Menu Section */}
              <div className="lg:col-span-2 space-y-8">
                <header className="flex justify-between items-end">
                  <div>
                    <h1 className="text-3xl font-bold mb-1">{t.posTerminal}</h1>
                    <p className="text-zinc-500">{t.welcome}, {currentUser.name}</p>
                  </div>
                  <div className="flex flex-col items-end gap-2">
                    <div className="flex gap-2">
                      <button 
                        onClick={() => setLang(lang === 'en' ? 'km' : 'en')}
                        className="px-3 py-1 bg-white/5 rounded-full text-xs text-zinc-400 border border-white/10 flex items-center gap-2 hover:bg-white/10 transition-colors"
                      >
                        <Globe size={14} />
                        {lang === 'en' ? 'English' : 'ភាសាខ្មែរ'}
                      </button>
                      <div className={cn(
                        "px-3 py-1 rounded-full text-xs border flex items-center gap-2",
                        isOnline ? "bg-emerald-500/10 text-emerald-500 border-emerald-500/20" : "bg-red-500/10 text-red-500 border-red-500/20"
                      )}>
                        {isOnline ? <Cloud size={14} /> : <CloudOff size={14} />}
                        {isOnline ? t.online : t.offline}
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <button 
                        onClick={() => setIsHappyHour(!isHappyHour)}
                        className={cn(
                          "px-3 py-1 rounded-full text-xs border flex items-center gap-2 transition-all",
                          isHappyHour ? "bg-amber-500/10 text-amber-500 border-amber-500/20" : "bg-white/5 text-zinc-500 border-white/10"
                        )}
                      >
                        <Clock size={14} />
                        {t.happyHour} {isHappyHour ? '(ON)' : '(OFF)'}
                      </button>
                      <span className="px-3 py-1 bg-white/5 rounded-full text-xs text-zinc-400 border border-white/10">USD/KHR: 4,100</span>
                    </div>
                  </div>
                </header>

                <div className="bg-[#141414] p-4 rounded-2xl border border-white/5 flex items-center gap-4">
                  <UserIcon className="text-zinc-500" size={20} />
                  <input 
                    type="text" 
                    placeholder={t.customerName}
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    className="bg-transparent border-none outline-none flex-1 text-white placeholder:text-zinc-600"
                  />
                </div>

                <section>
                  <h2 className="text-sm font-semibold uppercase tracking-wider text-zinc-500 mb-4">Cocktails</h2>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                    {cocktails.map(cocktail => (
                      <button
                        key={cocktail.id}
                        onClick={() => addToCart(cocktail, 'cocktail')}
                        className="p-4 bg-[#141414] border border-white/5 rounded-2xl text-left hover:border-emerald-500/50 hover:bg-emerald-500/5 transition-all group"
                      >
                        <div className="w-12 h-12 bg-emerald-500/10 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                          <Wine className="text-emerald-500" size={24} />
                        </div>
                        <h3 className="font-semibold text-lg mb-1">{lang === 'km' && cocktail.nameKh ? cocktail.nameKh : cocktail.name}</h3>
                        <div className="flex items-center justify-between">
                          <p className="text-emerald-500 font-bold">${(isHappyHour ? cocktail.price * 0.8 : cocktail.price).toFixed(2)}</p>
                          {isHappyHour && <span className="text-[10px] text-amber-500 font-bold">-20%</span>}
                        </div>
                      </button>
                    ))}
                  </div>
                </section>

                <section>
                  <h2 className="text-sm font-semibold uppercase tracking-wider text-zinc-500 mb-4">Beers & Others</h2>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                    {stock.filter(s => s.category === 'Beer' || s.category === 'Soft Drink').map(item => (
                      <button
                        key={item.id}
                        onClick={() => addToCart(item, 'stockItem')}
                        className="p-4 bg-[#141414] border border-white/5 rounded-2xl text-left hover:border-emerald-500/50 hover:bg-emerald-500/5 transition-all group"
                      >
                        <div className="w-12 h-12 bg-blue-500/10 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                          <Package className="text-blue-500" size={24} />
                        </div>
                        <h3 className="font-semibold text-lg mb-1">{lang === 'km' && item.nameKh ? item.nameKh : item.name}</h3>
                        <p className="text-emerald-500 font-bold">${(item.costPerUnit * 3).toFixed(2)}</p>
                      </button>
                    ))}
                  </div>
                </section>
              </div>

              {/* Cart Section */}
              <div className="bg-[#141414] rounded-3xl border border-white/5 flex flex-col overflow-hidden shadow-2xl relative">
                {isPrinting && (
                  <div className="absolute inset-0 bg-black/60 backdrop-blur-sm z-10 flex flex-col items-center justify-center space-y-4">
                    <Printer className="text-emerald-500 animate-bounce" size={48} />
                    <p className="font-bold">Printing Receipt...</p>
                  </div>
                )}
                
                <div className="p-6 border-b border-white/5 flex justify-between items-center">
                  <h2 className="text-xl font-bold flex items-center gap-2">
                    <ShoppingCart size={20} className="text-emerald-500" />
                    Current Order
                  </h2>
                  <button onClick={() => setCart([])} className="text-zinc-500 hover:text-red-400 transition-colors">
                    <Trash2 size={20} />
                  </button>
                </div>

                <div className="flex-1 overflow-y-auto p-6 space-y-4">
                  {cart.length === 0 ? (
                    <div className="h-full flex flex-col items-center justify-center text-zinc-600 space-y-4">
                      <div className="w-16 h-16 bg-white/5 rounded-full flex items-center justify-center">
                        <ShoppingCart size={32} />
                      </div>
                      <p>Your cart is empty</p>
                    </div>
                  ) : (
                    cart.map(item => (
                      <div key={item.id} className="flex items-center justify-between group">
                        <div className="flex-1">
                          <h4 className="font-medium">{item.name}</h4>
                          <p className="text-xs text-zinc-500">${item.price.toFixed(2)} each</p>
                        </div>
                        <div className="flex items-center gap-3 bg-white/5 rounded-lg p-1">
                          <button onClick={() => updateCartQuantity(item.id, -1)} className="p-1 hover:bg-white/10 rounded transition-colors"><Minus size={14} /></button>
                          <span className="w-6 text-center font-bold">{item.quantity}</span>
                          <button onClick={() => updateCartQuantity(item.id, 1)} className="p-1 hover:bg-white/10 rounded transition-colors"><Plus size={14} /></button>
                        </div>
                        <div className="w-20 text-right font-bold text-emerald-500 ml-4">
                          ${(item.price * item.quantity).toFixed(2)}
                        </div>
                      </div>
                    ))
                  )}
                </div>

                <div className="p-6 bg-white/5 border-t border-white/5 space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between text-zinc-400">
                      <span>Subtotal</span>
                      <span>${cartTotal.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between text-xl font-bold">
                      <span>Total</span>
                      <div className="text-right">
                        <p className="text-emerald-500">${cartTotal.toFixed(2)}</p>
                        <p className="text-[10px] text-zinc-500 font-normal">≈ {(cartTotal * 4100).toLocaleString()} KHR</p>
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-3">
                    <button 
                      disabled={cart.length === 0}
                      onClick={() => handleCheckout('Cash')}
                      className="flex flex-col items-center justify-center gap-1 p-3 bg-white/5 hover:bg-white/10 border border-white/10 rounded-2xl font-bold transition-all disabled:opacity-50"
                    >
                      <DollarSign size={18} />
                      <span className="text-[10px] uppercase tracking-wider">{t.cash}</span>
                    </button>
                    <button 
                      disabled={cart.length === 0}
                      onClick={() => handleCheckout('ABA')}
                      className="flex flex-col items-center justify-center gap-1 p-3 bg-emerald-500 hover:bg-emerald-600 text-white rounded-2xl font-bold shadow-lg shadow-emerald-500/20 transition-all disabled:opacity-50"
                    >
                      <QrCode size={18} />
                      <span className="text-[10px] uppercase tracking-wider">ABA Pay</span>
                    </button>
                    <button 
                      disabled={cart.length === 0}
                      onClick={() => handleCheckout('Tab')}
                      className="flex flex-col items-center justify-center gap-1 p-3 bg-blue-500 hover:bg-blue-600 text-white rounded-2xl font-bold shadow-lg shadow-blue-500/20 transition-all disabled:opacity-50"
                    >
                      <Users size={18} />
                      <span className="text-[10px] uppercase tracking-wider">{t.openTab}</span>
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {activeTab === 'inventory' && (
            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="space-y-8"
            >
              <header className="flex justify-between items-center">
                <div>
                  <h1 className="text-3xl font-bold mb-1">{t.inventory}</h1>
                  <p className="text-zinc-500">Track and manage your bar stock</p>
                </div>
                <div className="flex gap-3">
                  <button onClick={() => {
                    const itemId = prompt('Enter Item ID:');
                    const qty = Number(prompt('Enter Quantity to Waste:'));
                    const reason = prompt('Enter Reason:');
                    if (itemId && qty && reason) handleAddWaste(itemId, qty, reason);
                  }} className="flex items-center gap-2 px-4 py-2 bg-red-500/10 text-red-500 border border-red-500/20 rounded-xl font-bold hover:bg-red-500/20 transition-all">
                    <Trash2 size={18} />
                    {t.waste}
                  </button>
                  <button onClick={() => {
                    const supplierId = prompt('Enter Supplier ID:');
                    const itemId = prompt('Enter Item ID:');
                    const qty = Number(prompt('Enter Quantity:'));
                    const cost = Number(prompt('Enter Cost Price:'));
                    if (supplierId && itemId && qty && cost) handleStockIn(supplierId, [{ stockItemId: itemId, quantity: qty, costPrice: cost }], qty * cost);
                  }} className="flex items-center gap-2 px-4 py-2 bg-blue-500/10 text-blue-500 border border-blue-500/20 rounded-xl font-bold hover:bg-blue-500/20 transition-all">
                    <Package size={18} />
                    {t.stockIn}
                  </button>
                  <button className="flex items-center gap-2 px-6 py-3 bg-emerald-500 rounded-2xl font-bold hover:bg-emerald-600 transition-all">
                    <Plus size={20} />
                    {t.addItem}
                  </button>
                </div>
              </header>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="p-6 bg-red-500/10 border border-red-500/20 rounded-3xl">
                  <div className="flex items-center gap-3 text-red-500 mb-2">
                    <AlertCircle size={20} />
                    <span className="font-bold">Low Stock Alert</span>
                  </div>
                  <p className="text-2xl font-bold">{stock.filter(s => s.quantity <= s.minThreshold).length} Items</p>
                </div>
                <div className="p-6 bg-emerald-500/10 border border-emerald-500/20 rounded-3xl">
                  <div className="flex items-center gap-3 text-emerald-500 mb-2">
                    <TrendingUp size={20} />
                    <span className="font-bold">Total Value</span>
                  </div>
                  <p className="text-2xl font-bold">${stock.reduce((sum, s) => sum + (s.quantity * s.costPerUnit), 0).toFixed(2)}</p>
                </div>
              </div>

              <div className="bg-[#141414] rounded-3xl border border-white/5 overflow-hidden">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-white/5 text-zinc-500 text-xs uppercase tracking-wider">
                      <th className="p-4 font-semibold">Item Name</th>
                      <th className="p-4 font-semibold">Category</th>
                      <th className="p-4 font-semibold">Current Stock</th>
                      <th className="p-4 font-semibold">Supplier</th>
                      <th className="p-4 font-semibold">Status</th>
                      <th className="p-4 font-semibold">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5">
                    {stock.map(item => (
                      <tr key={item.id} className="hover:bg-white/5 transition-colors group">
                        <td className="p-4">
                          <div className="font-medium">{item.name}</div>
                          <div className="text-xs text-zinc-500">{item.nameKh}</div>
                        </td>
                        <td className="p-4 text-zinc-400">{item.category}</td>
                        <td className="p-4 font-mono">{item.quantity} {item.unit}</td>
                        <td className="p-4 text-zinc-500">{suppliers.find(s => s.id === item.supplierId)?.name || 'N/A'}</td>
                        <td className="p-4">
                          {item.quantity <= item.minThreshold ? (
                            <span className="px-2 py-1 bg-red-500/10 text-red-500 text-[10px] font-bold rounded-full border border-red-500/20 uppercase">Low Stock</span>
                          ) : (
                            <span className="px-2 py-1 bg-emerald-500/10 text-emerald-500 text-[10px] font-bold rounded-full border border-emerald-500/20 uppercase">Healthy</span>
                          )}
                        </td>
                        <td className="p-4">
                          <button className="p-2 text-zinc-500 hover:text-white transition-colors"><Settings size={18} /></button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </motion.div>
          )}

          {activeTab === 'cocktails' && (
            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="space-y-8"
            >
              <header className="flex justify-between items-center">
                <div>
                  <h1 className="text-3xl font-bold mb-1">{t.cocktails}</h1>
                  <p className="text-zinc-500">Manage your cocktail recipes and pricing</p>
                </div>
                <div className="flex gap-3">
                  <button 
                    onClick={handleGetPricingSuggestions}
                    disabled={aiLoading}
                    className="flex items-center gap-2 px-4 py-2 bg-amber-500/10 text-amber-500 border border-amber-500/20 rounded-xl font-bold hover:bg-amber-500/20 transition-all disabled:opacity-50"
                  >
                    <Sparkles size={18} />
                    AI Pricing
                  </button>
                  <button className="flex items-center gap-2 px-6 py-3 bg-emerald-500 rounded-2xl font-bold hover:bg-emerald-600 transition-all">
                    <Plus size={20} />
                    Add Cocktail
                  </button>
                </div>
              </header>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {pricingSuggestions && (
                  <div className="col-span-full p-6 bg-amber-500/10 border border-amber-500/20 rounded-3xl mb-4">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-3 text-amber-500">
                        <Sparkles size={20} />
                        <h3 className="font-bold">AI Pricing Suggestions</h3>
                      </div>
                      <button onClick={() => setPricingSuggestions(null)} className="text-zinc-500 hover:text-white"><Trash2 size={16} /></button>
                    </div>
                    <div className="prose prose-invert prose-sm max-w-none">
                      <ReactMarkdown>{pricingSuggestions}</ReactMarkdown>
                    </div>
                  </div>
                )}
                {cocktails.map(cocktail => (
                  <div key={cocktail.id} className="p-6 bg-[#141414] border border-white/5 rounded-3xl space-y-4 group hover:border-emerald-500/30 transition-all">
                    <div className="flex justify-between items-start">
                      <div className="w-12 h-12 bg-emerald-500/10 rounded-2xl flex items-center justify-center">
                        <Wine className="text-emerald-500" size={24} />
                      </div>
                      <div className="text-right">
                        <div className="text-2xl font-bold text-emerald-500">${cocktail.price.toFixed(2)}</div>
                        <div className="text-[10px] text-zinc-500 uppercase tracking-wider">Price</div>
                      </div>
                    </div>
                    <div>
                      <h3 className="text-xl font-bold">{cocktail.name}</h3>
                      <p className="text-sm text-zinc-500">{cocktail.nameKh}</p>
                    </div>
                    <div className="space-y-2">
                      <p className="text-xs font-semibold uppercase tracking-wider text-zinc-500">Ingredients</p>
                      {cocktail.ingredients.map((ing, idx) => {
                        const item = stock.find(s => s.id === ing.stockItemId);
                        return (
                          <div key={idx} className="flex justify-between text-sm">
                            <span className="text-zinc-400">{item?.name}</span>
                            <span className="text-zinc-500">{ing.amount} {item?.unit}</span>
                          </div>
                        );
                      })}
                    </div>
                    <div className="pt-4 flex gap-2">
                      <button className="flex-1 py-2 bg-white/5 hover:bg-white/10 rounded-xl text-xs font-bold transition-all">Edit Recipe</button>
                      <button className="p-2 bg-white/5 hover:bg-white/10 rounded-xl text-red-400 transition-all"><Trash2 size={16} /></button>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          )}

          {activeTab === 'tabs' && (
            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="space-y-8"
            >
              <header>
                <h1 className="text-3xl font-bold mb-1">{t.activeTabs}</h1>
                <p className="text-zinc-500">Manage open customer tabs</p>
              </header>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {tabs.filter(tab => tab.status === 'Open').map(tab => (
                  <div key={tab.id} className="p-6 bg-[#141414] border border-white/5 rounded-3xl space-y-4">
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="text-xl font-bold">{tab.customerName}</h3>
                        <p className="text-xs text-zinc-500">Opened: {new Date(tab.openedAt).toLocaleTimeString()}</p>
                      </div>
                      <div className="px-3 py-1 bg-blue-500/10 text-blue-500 text-[10px] font-bold rounded-full border border-blue-500/20 uppercase">Open</div>
                    </div>
                    <div className="space-y-2">
                      {tab.items.map((item, idx) => (
                        <div key={idx} className="flex justify-between text-sm">
                          <span className="text-zinc-400">{item.quantity}x {item.name}</span>
                          <span>${(item.price * item.quantity).toFixed(2)}</span>
                        </div>
                      ))}
                    </div>
                    <div className="pt-4 border-t border-white/5 flex justify-between items-center">
                      <div className="text-xl font-bold text-emerald-500">${tab.total.toFixed(2)}</div>
                      <button 
                        onClick={() => {
                          setCart(tab.items);
                          setCustomerName(tab.customerName);
                          setTabs(tabs.filter(t => t.id !== tab.id));
                          setActiveTab('pos');
                        }}
                        className="px-4 py-2 bg-white/5 hover:bg-white/10 rounded-xl text-sm font-bold transition-all"
                      >
                        Reopen
                      </button>
                    </div>
                  </div>
                ))}
                {tabs.filter(tab => tab.status === 'Open').length === 0 && (
                  <div className="col-span-full py-20 text-center text-zinc-600">
                    <Users className="mx-auto mb-4 opacity-20" size={48} />
                    <p>No active tabs</p>
                  </div>
                )}
              </div>
            </motion.div>
          )}

          {activeTab === 'expenses' && (
            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="space-y-8"
            >
              <header className="flex justify-between items-center">
                <div>
                  <h1 className="text-3xl font-bold mb-1">{t.expenses}</h1>
                  <p className="text-zinc-500">Track petty cash and bar expenses</p>
                </div>
                <div className="flex gap-3">
                  <button 
                    onClick={() => {
                      const amt = parseFloat(prompt("Amount to Take ($):") || "0");
                      const desc = prompt("Reason for taking cash:");
                      if (amt && desc) handleAddExpense(desc, amt, "Petty Cash", "CashTaken");
                    }}
                    className="flex items-center gap-2 px-4 py-2 bg-orange-500/10 text-orange-500 border border-orange-500/20 rounded-xl font-bold hover:bg-orange-500/20 transition-all"
                  >
                    <Minus size={18} />
                    {t.cashTaken}
                  </button>
                  <button 
                    onClick={() => {
                      const amt = parseFloat(prompt("Amount to Return ($):") || "0");
                      const desc = prompt("Reason for returning cash:");
                      if (amt && desc) handleAddExpense(desc, amt, "Petty Cash", "CashReturned");
                    }}
                    className="flex items-center gap-2 px-4 py-2 bg-blue-500/10 text-blue-500 border border-blue-500/20 rounded-xl font-bold hover:bg-blue-500/20 transition-all"
                  >
                    <Plus size={18} />
                    {t.cashReturned}
                  </button>
                  <button 
                    onClick={() => {
                      const desc = prompt("Expense Description:");
                      const amt = parseFloat(prompt("Amount ($):") || "0");
                      const cat = prompt("Category:") || "General";
                      if (desc && amt) handleAddExpense(desc, amt, cat, "Expense");
                    }}
                    className="flex items-center gap-2 px-6 py-3 bg-emerald-500 rounded-2xl font-bold hover:bg-emerald-600 transition-all"
                  >
                    <Plus size={20} />
                    {t.addExpense}
                  </button>
                </div>
              </header>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="p-6 bg-[#141414] border border-white/5 rounded-3xl">
                  <p className="text-zinc-500 text-xs uppercase tracking-wider mb-1">Current Petty Cash Out</p>
                  <p className="text-2xl font-bold text-orange-500">
                    ${expenses.reduce((sum, e) => {
                      if (e.type === 'CashTaken') return sum + e.amount;
                      if (e.type === 'CashReturned') return sum - e.amount;
                      return sum;
                    }, 0).toFixed(2)}
                  </p>
                </div>
              </div>

              <div className="bg-[#141414] rounded-3xl border border-white/5 overflow-hidden">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-white/5 text-zinc-500 text-xs uppercase tracking-wider">
                      <th className="p-4 font-semibold">Date</th>
                      <th className="p-4 font-semibold">Type</th>
                      <th className="p-4 font-semibold">Description</th>
                      <th className="p-4 font-semibold">Amount</th>
                      <th className="p-4 font-semibold">Staff</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5">
                    {expenses.map(exp => (
                      <tr key={exp.id} className="hover:bg-white/5 transition-colors">
                        <td className="p-4 text-zinc-400 text-sm">{new Date(exp.timestamp).toLocaleDateString()}</td>
                        <td className="p-4">
                          <span className={cn(
                            "px-2 py-1 rounded-full text-[10px] uppercase tracking-wider font-bold",
                            exp.type === 'Expense' ? "bg-red-500/10 text-red-500" :
                            exp.type === 'CashTaken' ? "bg-orange-500/10 text-orange-500" :
                            "bg-blue-500/10 text-blue-500"
                          )}>
                            {exp.type === 'Expense' ? t.expenses : exp.type === 'CashTaken' ? t.cashTaken : t.cashReturned}
                          </span>
                        </td>
                        <td className="p-4 font-medium">{exp.description}</td>
                        <td className={cn(
                          "p-4 font-bold",
                          exp.type === 'CashReturned' ? "text-emerald-500" : "text-red-400"
                        )}>
                          {exp.type === 'CashReturned' ? '+' : '-'}${exp.amount.toFixed(2)}
                        </td>
                        <td className="p-4 text-zinc-500 text-sm">{exp.staffMember}</td>
                      </tr>
                    ))}
                    {expenses.length === 0 && (
                      <tr>
                        <td colSpan={5} className="p-20 text-center text-zinc-600">
                          <Wallet className="mx-auto mb-4 opacity-20" size={48} />
                          <p>No expenses recorded</p>
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </motion.div>
          )}

          {activeTab === 'history' && (
            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="space-y-8"
            >
              <header>
                <h1 className="text-3xl font-bold mb-1">{t.history}</h1>
                <p className="text-zinc-500">View all completed transactions</p>
              </header>

              <div className="bg-[#141414] rounded-3xl border border-white/5 overflow-hidden">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-white/5 text-zinc-500 text-xs uppercase tracking-wider">
                      <th className="p-4 font-semibold">Order ID</th>
                      <th className="p-4 font-semibold">Date</th>
                      <th className="p-4 font-semibold">Customer</th>
                      <th className="p-4 font-semibold">Total</th>
                      <th className="p-4 font-semibold">Payment</th>
                      <th className="p-4 font-semibold">Staff</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5">
                    {orders.map(order => (
                      <tr key={order.id} className="hover:bg-white/5 transition-colors">
                        <td className="p-4 font-mono text-xs">{order.id}</td>
                        <td className="p-4 text-zinc-400 text-sm">{new Date(order.timestamp).toLocaleString()}</td>
                        <td className="p-4 font-medium">{order.customerName || 'Guest'}</td>
                        <td className="p-4 font-bold text-emerald-500">${order.total.toFixed(2)}</td>
                        <td className="p-4">
                          <span className="px-2 py-1 bg-white/5 rounded-full text-[10px] uppercase tracking-wider">{order.paymentMethod}</span>
                        </td>
                        <td className="p-4 text-zinc-500 text-sm">{order.processedBy}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </motion.div>
          )}

          {activeTab === 'loyalty' && (
            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="space-y-8"
            >
              <header className="flex justify-between items-center">
                <div>
                  <h1 className="text-3xl font-bold mb-1">{t.loyalty}</h1>
                  <p className="text-zinc-500">Manage customer rewards and visits</p>
                </div>
                <button 
                  onClick={() => {
                    const name = prompt("Customer Name:");
                    const phone = prompt("Phone Number:");
                    if (name && phone) {
                      setLoyaltyMembers([...loyaltyMembers, {
                        id: `LOY-${Date.now()}`,
                        name,
                        phone,
                        points: 0,
                        visitCount: 0,
                        lastVisit: Date.now()
                      }]);
                    }
                  }}
                  className="flex items-center gap-2 px-6 py-3 bg-emerald-500 rounded-2xl font-bold hover:bg-emerald-600 transition-all"
                >
                  <Plus size={20} />
                  Add Member
                </button>
              </header>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {loyaltyMembers.map(member => (
                  <div key={member.id} className="p-6 bg-[#141414] border border-white/5 rounded-3xl space-y-4">
                    <div className="flex justify-between items-start">
                      <div className="w-12 h-12 bg-emerald-500/10 rounded-2xl flex items-center justify-center">
                        <Sparkles className="text-emerald-500" size={24} />
                      </div>
                      <div className="text-right">
                        <div className="text-2xl font-bold text-emerald-500">{member.points}</div>
                        <div className="text-[10px] text-zinc-500 uppercase tracking-wider">{t.points}</div>
                      </div>
                    </div>
                    <div>
                      <h3 className="text-xl font-bold">{member.name}</h3>
                      <p className="text-sm text-zinc-500">{member.phone}</p>
                    </div>
                    <div className="flex justify-between text-xs text-zinc-500 pt-2 border-t border-white/5">
                      <span>{t.visits}: {member.visitCount}</span>
                      <span>Last: {new Date(member.lastVisit).toLocaleDateString()}</span>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          )}

          {activeTab === 'staff' && (
            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="space-y-8"
            >
              <header className="flex justify-between items-center">
                <div>
                  <h1 className="text-3xl font-bold mb-1">{t.staff}</h1>
                  <p className="text-zinc-500">Manage staff access and roles</p>
                </div>
                <button 
                  onClick={() => {
                    const name = prompt("Staff Name:");
                    const pin = prompt("4-Digit PIN:");
                    const role = prompt("Role (Manager/Bartender):") as Role;
                    if (name && pin && role) {
                      setUsers([...users, { id: `u${Date.now()}`, name, pin, role, active: true }]);
                    }
                  }}
                  className="flex items-center gap-2 px-6 py-3 bg-emerald-500 rounded-2xl font-bold hover:bg-emerald-600 transition-all"
                >
                  <Plus size={20} />
                  Add Staff
                </button>
              </header>

              <div className="bg-[#141414] rounded-3xl border border-white/5 overflow-hidden">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-white/5 text-zinc-500 text-xs uppercase tracking-wider">
                      <th className="p-4 font-semibold">Name</th>
                      <th className="p-4 font-semibold">Role</th>
                      <th className="p-4 font-semibold">PIN</th>
                      <th className="p-4 font-semibold">Status</th>
                      <th className="p-4 font-semibold">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5">
                    {users.map(user => (
                      <tr key={user.id} className="hover:bg-white/5 transition-colors">
                        <td className="p-4 font-medium">{user.name}</td>
                        <td className="p-4">
                          <span className={cn(
                            "px-2 py-1 rounded-full text-[10px] uppercase tracking-wider font-bold",
                            user.role === 'Manager' ? "bg-purple-500/10 text-purple-500" : "bg-blue-500/10 text-blue-500"
                          )}>
                            {user.role}
                          </span>
                        </td>
                        <td className="p-4 font-mono">****</td>
                        <td className="p-4">
                          <span className={cn(
                            "px-2 py-1 rounded-full text-[10px] uppercase tracking-wider font-bold",
                            user.active ? "bg-emerald-500/10 text-emerald-500" : "bg-red-500/10 text-red-500"
                          )}>
                            {user.active ? 'Active' : 'Inactive'}
                          </span>
                        </td>
                        <td className="p-4">
                          <button 
                            onClick={() => setUsers(users.map(u => u.id === user.id ? { ...u, active: !u.active } : u))}
                            className="text-xs font-bold text-zinc-500 hover:text-white transition-all"
                          >
                            Toggle Status
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </motion.div>
          )}

          {activeTab === 'suppliers' && (
            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="space-y-8"
            >
              <header className="flex justify-between items-center">
                <div>
                  <h1 className="text-3xl font-bold mb-1">{t.suppliers}</h1>
                  <p className="text-zinc-500">Manage your product suppliers</p>
                </div>
                <button 
                  onClick={() => {
                    const name = prompt("Supplier Name:");
                    const contact = prompt("Contact Number:");
                    const cat = prompt("Category:");
                    if (name && contact && cat) {
                      setSuppliers([...suppliers, { id: `s${Date.now()}`, name, contact, category: cat }]);
                    }
                  }}
                  className="flex items-center gap-2 px-6 py-3 bg-emerald-500 rounded-2xl font-bold hover:bg-emerald-600 transition-all"
                >
                  <Plus size={20} />
                  Add Supplier
                </button>
              </header>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {suppliers.map(supplier => (
                  <div key={supplier.id} className="p-6 bg-[#141414] border border-white/5 rounded-3xl space-y-4">
                    <div className="w-12 h-12 bg-blue-500/10 rounded-2xl flex items-center justify-center">
                      <Grid3X3 className="text-blue-500" size={24} />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold">{supplier.name}</h3>
                      <p className="text-sm text-zinc-500">{supplier.category}</p>
                    </div>
                    <div className="space-y-1">
                      <p className="text-xs text-zinc-400">Contact: {supplier.contact}</p>
                      {supplier.email && <p className="text-xs text-zinc-400">Email: {supplier.email}</p>}
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          )}

          {activeTab === 'waste' && (
            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="space-y-8"
            >
              <header>
                <h1 className="text-3xl font-bold mb-1">{t.waste}</h1>
                <p className="text-zinc-500">Track and manage discarded stock</p>
              </header>

              <div className="bg-[#141414] rounded-3xl border border-white/5 overflow-hidden">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-white/5 text-zinc-500 text-xs uppercase tracking-wider">
                      <th className="p-4 font-semibold">Date</th>
                      <th className="p-4 font-semibold">Item</th>
                      <th className="p-4 font-semibold">Quantity</th>
                      <th className="p-4 font-semibold">Reason</th>
                      <th className="p-4 font-semibold">Staff</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5">
                    {wasteLogs.map(log => {
                      const item = stock.find(s => s.id === log.stockItemId);
                      return (
                        <tr key={log.id} className="hover:bg-white/5 transition-colors">
                          <td className="p-4 text-zinc-400 text-sm">{new Date(log.timestamp).toLocaleDateString()}</td>
                          <td className="p-4 font-medium">{item?.name || 'Unknown'}</td>
                          <td className="p-4 font-mono">{log.quantity} {item?.unit}</td>
                          <td className="p-4 text-zinc-500">{log.reason}</td>
                          <td className="p-4 text-zinc-500 text-sm">{log.processedBy}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </motion.div>
          )}

          {activeTab === 'stockIn' && (
            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="space-y-8"
            >
              <header className="flex justify-between items-center">
                <div>
                  <h1 className="text-3xl font-bold mb-1">{t.stockIn}</h1>
                  <p className="text-zinc-500">Track and manage product deliveries</p>
                </div>
                <button 
                  onClick={() => {
                    const supplierId = prompt('Enter Supplier ID:');
                    const itemId = prompt('Enter Item ID:');
                    const qty = Number(prompt('Enter Quantity:'));
                    const cost = Number(prompt('Enter Cost Price:'));
                    if (supplierId && itemId && qty && cost) handleStockIn(supplierId, [{ stockItemId: itemId, quantity: qty, costPrice: cost }], qty * cost);
                  }}
                  className="flex items-center gap-2 px-6 py-3 bg-emerald-500 rounded-2xl font-bold hover:bg-emerald-600 transition-all"
                >
                  <Plus size={20} />
                  Add Delivery
                </button>
              </header>

              <div className="bg-[#141414] rounded-3xl border border-white/5 overflow-hidden">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-white/5 text-zinc-500 text-xs uppercase tracking-wider">
                      <th className="p-4 font-semibold">Date</th>
                      <th className="p-4 font-semibold">Supplier</th>
                      <th className="p-4 font-semibold">Total Cost</th>
                      <th className="p-4 font-semibold">Staff</th>
                      <th className="p-4 font-semibold">Invoice</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5">
                    {stockInLogs.map(log => {
                      const supplier = suppliers.find(s => s.id === log.supplierId);
                      return (
                        <tr key={log.id} className="hover:bg-white/5 transition-colors">
                          <td className="p-4 text-zinc-400 text-sm">{new Date(log.timestamp).toLocaleDateString()}</td>
                          <td className="p-4 font-medium">{supplier?.name || 'Unknown'}</td>
                          <td className="p-4 font-bold text-emerald-500">${log.totalCost.toFixed(2)}</td>
                          <td className="p-4 text-zinc-500 text-sm">{log.staffMember}</td>
                          <td className="p-4">
                            {log.invoicePhoto ? (
                              <button className="text-emerald-500 hover:underline text-xs">View Photo</button>
                            ) : (
                              <span className="text-zinc-600 text-xs">No Photo</span>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </motion.div>
          )}

          {activeTab === 'analytics' && (
            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="space-y-8"
            >
              <header>
                <h1 className="text-3xl font-bold mb-1">{t.analytics}</h1>
                <p className="text-zinc-500">Visual performance data</p>
              </header>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="p-6 bg-[#141414] border border-white/5 rounded-3xl h-[400px]">
                  <h3 className="text-lg font-bold mb-6">Sales by Hour</h3>
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={orders.reduce((acc: any[], order) => {
                      const hour = new Date(order.timestamp).getHours();
                      const existing = acc.find(a => a.hour === hour);
                      if (existing) existing.total += order.total;
                      else acc.push({ hour, total: order.total });
                      return acc;
                    }, []).sort((a, b) => a.hour - b.hour)}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                      <XAxis dataKey="hour" stroke="#666" />
                      <YAxis stroke="#666" />
                      <Tooltip contentStyle={{ backgroundColor: '#141414', border: '1px solid #333' }} />
                      <Bar dataKey="total" fill="#10b981" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>

                <div className="p-6 bg-[#141414] border border-white/5 rounded-3xl h-[400px]">
                  <h3 className="text-lg font-bold mb-6">Top Selling Items</h3>
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={orders.flatMap(o => o.items).reduce((acc: any[], item) => {
                          const existing = acc.find(a => a.name === item.name);
                          if (existing) existing.value += item.quantity;
                          else acc.push({ name: item.name, value: item.quantity });
                          return acc;
                        }, []).sort((a, b) => b.value - a.value).slice(0, 5)}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={80}
                        paddingAngle={5}
                        dataKey="value"
                      >
                        {['#10b981', '#3b82f6', '#f59e0b', '#ef4444', '#8b5cf6'].map((color, index) => (
                          <Cell key={`cell-${index}`} fill={color} />
                        ))}
                      </Pie>
                      <Tooltip contentStyle={{ backgroundColor: '#141414', border: '1px solid #333' }} />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </motion.div>
          )}

          {activeTab === 'reports' && (
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="max-w-4xl mx-auto space-y-8"
            >
              <div className="p-12 bg-gradient-to-br from-emerald-500/20 to-blue-500/20 rounded-[3rem] border border-white/10 text-center relative overflow-hidden">
                <div className="absolute top-0 left-0 w-full h-full bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-10 pointer-events-none"></div>
                <Sparkles className="mx-auto text-emerald-400 mb-6" size={48} />
                <h1 className="text-4xl font-bold mb-4">Gemini AI Insights</h1>
                <p className="text-zinc-400 text-lg mb-8 max-w-xl mx-auto">Get intelligent reports on your bar's performance, pricing suggestions, and inventory optimization.</p>
                <button 
                  onClick={handleGenerateReport}
                  disabled={aiLoading}
                  className="px-10 py-4 bg-emerald-500 hover:bg-emerald-600 rounded-2xl font-bold text-lg shadow-xl shadow-emerald-500/20 transition-all disabled:opacity-50 flex items-center gap-3 mx-auto"
                >
                  {aiLoading ? (
                    <div className="w-6 h-6 border-4 border-white/30 border-t-white rounded-full animate-spin"></div>
                  ) : (
                    <Sparkles size={24} />
                  )}
                  Generate Weekly Report
                </button>
              </div>

              {aiReport && (
                <motion.div 
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="p-8 bg-[#141414] border border-white/5 rounded-[2.5rem] prose prose-invert max-w-none"
                >
                  <ReactMarkdown>{aiReport}</ReactMarkdown>
                </motion.div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* ABA Modal */}
      <AnimatePresence>
        {isAbaModalOpen && (
          <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50 p-4">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="bg-[#141414] w-full max-w-md rounded-[2.5rem] border border-white/10 overflow-hidden shadow-2xl"
            >
              <div className="p-8 text-center space-y-6">
                <div className="w-20 h-20 bg-emerald-500/10 rounded-3xl flex items-center justify-center mx-auto">
                  <QrCode className="text-emerald-500" size={40} />
                </div>
                <div>
                  <h2 className="text-2xl font-bold mb-2">ABA PayWay</h2>
                  <p className="text-zinc-500">{t.scanQr}</p>
                </div>
                
                <div className="bg-white p-6 rounded-3xl aspect-square flex items-center justify-center shadow-inner">
                  {abaQr ? (
                    <img src={abaQr} alt="ABA QR" className="w-full h-full" referrerPolicy="no-referrer" />
                  ) : (
                    <div className="w-full h-full bg-zinc-100 animate-pulse rounded-xl"></div>
                  )}
                </div>

                <div className="text-3xl font-bold text-emerald-500">
                  ${cartTotal.toFixed(2)}
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <button 
                    onClick={() => setIsAbaModalOpen(false)}
                    className="p-4 bg-white/5 hover:bg-white/10 rounded-2xl font-bold transition-all"
                  >
                    {t.cancel}
                  </button>
                  <button 
                    onClick={() => completeOrder('ABA')}
                    className="p-4 bg-emerald-500 hover:bg-emerald-600 rounded-2xl font-bold transition-all"
                  >
                    {t.confirmPaid}
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
