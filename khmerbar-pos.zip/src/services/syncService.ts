/**
 * Service to handle synchronization with Google Sheets.
 * In a real app, this would use the access tokens from OAuth.
 */

export const syncToGoogleSheets = async (data: { orders: any[], stock: any[], expenses: any[] }, tokens: any) => {
  if (!tokens) {
    console.warn("No Google tokens found. Saving locally only.");
    // Save to localStorage for offline mode
    localStorage.setItem('pos_backup', JSON.stringify({ ...data, lastSync: Date.now() }));
    return false;
  }

  try {
    // This would call our backend /api/sync which uses googleapis
    const response = await fetch('/api/sync/sheets', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${tokens.access_token}`
      },
      body: JSON.stringify(data)
    });

    if (response.ok) {
      console.log("Synced to Google Sheets successfully!");
      return true;
    }
    return false;
  } catch (error) {
    console.error("Sync failed:", error);
    return false;
  }
};

export const getOfflineData = () => {
  const data = localStorage.getItem('pos_backup');
  return data ? JSON.parse(data) : null;
};
