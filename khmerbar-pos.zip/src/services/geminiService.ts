import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export const getPricingSuggestions = async (cocktails: any[], stock: any[]) => {
  const prompt = `As a bar consultant in Cambodia, suggest retail prices for these cocktails: ${JSON.stringify(cocktails)}. 
  Base your analysis on these current stock costs: ${JSON.stringify(stock)}.
  Consider that the average cocktail price in Phnom Penh is between $4 and $8. 
  Return a JSON object with 'suggestions' (string in Markdown format) containing specific advice for each cocktail.`;

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          suggestions: { type: Type.STRING },
        },
        required: ["suggestions"],
      },
    },
  });

  const data = JSON.parse(response.text || "{}");
  return data.suggestions;
};

export const generateWeeklyReport = async (salesData: any[]) => {
  const prompt = `Analyze this weekly sales data for a bar in Cambodia: ${JSON.stringify(salesData)}. 
  Provide a summary of top performing items, inventory alerts, and strategic advice for next week. 
  Format as Markdown.`;

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: prompt,
  });

  return response.text;
};

export const extractInvoiceData = async (base64Image: string) => {
  const prompt = `Extract the following details from this invoice image: 
  - Supplier Name
  - Date
  - Items (Name, Quantity, Unit Price)
  - Total Amount
  Return as a JSON object.`;

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: {
      parts: [
        { text: prompt },
        { inlineData: { data: base64Image, mimeType: "image/jpeg" } },
      ],
    },
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          supplierName: { type: Type.STRING },
          date: { type: Type.STRING },
          items: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                name: { type: Type.STRING },
                quantity: { type: Type.NUMBER },
                unitPrice: { type: Type.NUMBER },
              },
              required: ["name", "quantity", "unitPrice"],
            },
          },
          totalAmount: { type: Type.NUMBER },
        },
        required: ["supplierName", "date", "items", "totalAmount"],
      },
    },
  });

  return JSON.parse(response.text || "{}");
};
